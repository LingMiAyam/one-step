package onestep.repository;

import onestep.exception.DataAccessException;
import onestep.model.Goal;
import onestep.model.Status;
import onestep.model.Task;
import onestep.model.Ukuran;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
// >>> PERBAIKAN BUG 3 (awal) <<<
import java.util.Collections;
// >>> PERBAIKAN BUG 3 (akhir) <<<
import java.util.List;

/**
 * Implementasi TaskRepository menggunakan database SQLite.
 * Selalu mengaktifkan PRAGMA foreign_keys = ON dan memakai PreparedStatement.
 */
public class SqliteTaskRepository implements TaskRepository {

    private static final String SAMPLE_SEEDED_KEY = "sample_data_seeded";

    private final String dbUrl;

    public SqliteTaskRepository(String dbFileName) {
        this.dbUrl = "jdbc:sqlite:" + dbFileName;
    }

    private Connection getConnection() throws SQLException {
        Connection conn = DriverManager.getConnection(dbUrl);
        // WAJIB di SQLite agar ON DELETE CASCADE berfungsi
        try (Statement stmt = conn.createStatement()) {
            stmt.execute("PRAGMA foreign_keys = ON;");
        }
        return conn;
    }

    @Override
    public void initDatabase() {
        String sqlTasks = "CREATE TABLE IF NOT EXISTS tasks ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "name TEXT NOT NULL, "
                + "description TEXT, "
                + "deadline TEXT, "
                + "created_at TEXT NOT NULL"
                + ");";

        String sqlGoals = "CREATE TABLE IF NOT EXISTS goals ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "task_id INTEGER NOT NULL, "
                + "description TEXT NOT NULL, "
                + "ukuran TEXT NOT NULL, "
                + "status TEXT NOT NULL, "
                + "position INTEGER NOT NULL, "
                + "updated_at TEXT NOT NULL, "
                + "finished_at TEXT, "
                + "FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE"
                + ");";

        String sqlMetadata = "CREATE TABLE IF NOT EXISTS app_metadata ("
                + "meta_key TEXT PRIMARY KEY, "
                + "meta_value TEXT NOT NULL"
                + ");";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute(sqlTasks);
            stmt.execute(sqlGoals);
            stmt.execute(sqlMetadata);
            seedSampleDataOnce(conn);
        } catch (SQLException e) {
            throw new DataAccessException("Gagal menginisialisasi database SQLite.", e);
        }
    }

    /**
     * Mengisi data contoh otomatis hanya sekali saat pertama kali database dibuat.
     * Jika semua tugas dihapus lalu aplikasi ditutup dan dibuka kembali, dummy tidak muncul lagi.
     */
    private void seedSampleDataOnce(Connection conn) throws SQLException {
        if (isSampleDataSeeded(conn)) {
            return;
        }

        if (findAllTasksWithGoals().isEmpty()) {
            Task t1 = saveTask(new Task(
                    "Laporan Praktikum PBO",
                    "Laporan akhir praktikum Java GUI & OOP",
                    LocalDate.now().plusDays(3)
            ));
            saveGoal(new Goal(t1.getId(), "Rapikan daftar pustaka", Ukuran.S, 1));
            saveGoal(new Goal(t1.getId(), "Buat tabel hasil uji coba", Ukuran.M, 2));
            saveGoal(new Goal(t1.getId(), "Tulis pembahasan analisis OOP", Ukuran.L, 3));

            Task t2 = saveTask(new Task(
                    "Presentasi Final Project",
                    "Slide PPT dan latihan demo aplikasi",
                    LocalDate.now().plusDays(1)
            ));
            saveGoal(new Goal(t2.getId(), "Cek link GitHub di makalah", Ukuran.S, 1));
            saveGoal(new Goal(t2.getId(), "Susun slide masalah & solusi", Ukuran.M, 2));
        }

        markSampleDataSeeded(conn);
    }

    private boolean isSampleDataSeeded(Connection conn) throws SQLException {
        String sql = "SELECT meta_value FROM app_metadata WHERE meta_key = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, SAMPLE_SEEDED_KEY);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && "true".equals(rs.getString("meta_value"));
            }
        }
    }

    private void markSampleDataSeeded(Connection conn) throws SQLException {
        String sql = "INSERT OR REPLACE INTO app_metadata (meta_key, meta_value) VALUES (?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, SAMPLE_SEEDED_KEY);
            ps.setString(2, "true");
            ps.executeUpdate();
        }
    }

    @Override
    public List<Task> findAllTasksWithGoals() {
        List<Task> tasks = new ArrayList<>();
        String sql = "SELECT id, name, description, deadline, created_at FROM tasks ORDER BY id DESC";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Task task = mapTask(rs);
                task.setGoals(findGoalsByTaskId(conn, task.getId()));
                tasks.add(task);
            }
            return tasks;
        } catch (SQLException e) {
            throw new DataAccessException("Gagal memuat daftar tugas.", e);
        }
    }

    @Override
    public Task findTaskById(int taskId) {
        String sql = "SELECT id, name, description, deadline, created_at FROM tasks WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, taskId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Task task = mapTask(rs);
                    task.setGoals(findGoalsByTaskId(conn, task.getId()));
                    return task;
                }
                return null;
            }
        } catch (SQLException e) {
            throw new DataAccessException("Gagal memuat detail tugas.", e);
        }
    }

    private List<Goal> findGoalsByTaskId(Connection conn, int taskId) throws SQLException {
        List<Goal> goals = new ArrayList<>();
        String sql = "SELECT id, task_id, description, ukuran, status, position, updated_at, finished_at "
                   + "FROM goals WHERE task_id = ? ORDER BY position ASC, id ASC";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, taskId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    goals.add(mapGoal(rs));
                }
            }
        }
        return goals;
    }

    @Override
    public Task saveTask(Task task) {
        if (task.getId() == 0) {
            String sql = "INSERT INTO tasks (name, description, deadline, created_at) VALUES (?, ?, ?, ?)";
            try (Connection conn = getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, task.getName());
                ps.setString(2, task.getDescription());
                ps.setString(3, task.getDeadline() != null ? task.getDeadline().toString() : null);
                ps.setString(4, task.getCreatedAt().toString());
                ps.executeUpdate();

                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) {
                        task.setId(keys.getInt(1));
                    }
                }
                return task;
            } catch (SQLException e) {
                throw new DataAccessException("Gagal menyimpan tugas baru.", e);
            }
        } else {
            String sql = "UPDATE tasks SET name = ?, description = ?, deadline = ? WHERE id = ?";
            try (Connection conn = getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, task.getName());
                ps.setString(2, task.getDescription());
                ps.setString(3, task.getDeadline() != null ? task.getDeadline().toString() : null);
                ps.setInt(4, task.getId());
                ps.executeUpdate();
                return task;
            } catch (SQLException e) {
                throw new DataAccessException("Gagal memperbarui tugas.", e);
            }
        }
    }

    @Override
    public void deleteTask(int taskId) {
        String sql = "DELETE FROM tasks WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, taskId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DataAccessException("Gagal menghapus tugas.", e);
        }
    }

    @Override
    public Goal saveGoal(Goal goal) {
        String sql = "INSERT INTO goals (task_id, description, ukuran, status, position, updated_at, finished_at) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            // >>> PERBAIKAN BUG 3 (awal) <<<
            // Sebelumnya posisi memakai nilai kiriman GUI (jumlah target + 1), yang bisa
            // sama dengan posisi target lain setelah ada target yang dihapus.
            // Sekarang posisi baru = posisi terbesar di tugas ini + 1 (selalu unik).
            goal.setPosition(nextPositionForTask(conn, goal.getTaskId()));
            // >>> PERBAIKAN BUG 3 (akhir) <<<
            ps.setInt(1, goal.getTaskId());
            ps.setString(2, goal.getDescription());
            ps.setString(3, goal.getUkuran().name());
            ps.setString(4, goal.getStatus().name());
            ps.setInt(5, goal.getPosition());
            ps.setString(6, goal.getUpdatedAt().toString());
            ps.setString(7, goal.getFinishedAt() != null ? goal.getFinishedAt().toString() : null);
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    goal.setId(keys.getInt(1));
                }
            }
            return goal;
        } catch (SQLException e) {
            throw new DataAccessException("Gagal menyimpan target baru.", e);
        }
    }

    @Override
    public void updateGoalStatus(int goalId, Status status) {
        String sql = "UPDATE goals SET status = ?, updated_at = ?, finished_at = ? WHERE id = ?";
        LocalDateTime now = LocalDateTime.now();
        String finishedAt = (status == Status.SELESAI) ? now.toString() : null;

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status.name());
            ps.setString(2, now.toString());
            ps.setString(3, finishedAt);
            ps.setInt(4, goalId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DataAccessException("Gagal mengubah status target.", e);
        }
    }

    @Override
    public void deleteGoal(int goalId) {
        String sql = "DELETE FROM goals WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, goalId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DataAccessException("Gagal menghapus target.", e);
        }
    }

    // >>> PERBAIKAN BUG 3 (awal) <<<
    // Posisi terbesar di tugas ini + 1 (kalau belum ada target, hasilnya 1)
    private int nextPositionForTask(Connection conn, int taskId) throws SQLException {
        String sql = "SELECT COALESCE(MAX(position), 0) + 1 FROM goals WHERE task_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, taskId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 1;
            }
        }
    }

    //membaca urutan nyata target di database, menukar dua target itu, lalu menomori ulang semua target 1..n. Ini juga otomatis memperbaiki posisi ganda yang sudah terlanjur ada di database lama.
    @Override
    public void swapGoalPositions(Goal g1, Goal g2) {
        String selectSql = "SELECT id FROM goals WHERE task_id = ? ORDER BY position ASC, id ASC";
        String updateSql = "UPDATE goals SET position = ? WHERE id = ?";
        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false);
            try {
                List<Integer> urutan = new ArrayList<>();
                try (PreparedStatement ps = conn.prepareStatement(selectSql)) {
                    ps.setInt(1, g1.getTaskId());
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            urutan.add(rs.getInt("id"));
                        }
                    }
                }

                int idx1 = urutan.indexOf(g1.getId());
                int idx2 = urutan.indexOf(g2.getId());
                if (idx1 == -1 || idx2 == -1) {
                    throw new SQLException("Target tidak ditemukan di tugas ini.");
                }
                Collections.swap(urutan, idx1, idx2);

                try (PreparedStatement ps = conn.prepareStatement(updateSql)) {
                    for (int i = 0; i < urutan.size(); i++) {
                        ps.setInt(1, i + 1);
                        ps.setInt(2, urutan.get(i));
                        ps.executeUpdate();
                    }
                }
                conn.commit();
            } catch (SQLException ex) {
                conn.rollback();
                throw ex;
            }
        } catch (SQLException e) {
            throw new DataAccessException("Gagal mengubah urutan target.", e);
        }
    }

    private Task mapTask(ResultSet rs) throws SQLException {
        String dl = rs.getString("deadline");
        LocalDate deadline = (dl != null && !dl.isEmpty()) ? LocalDate.parse(dl) : null;
        LocalDateTime createdAt = LocalDateTime.parse(rs.getString("created_at"));
        return new Task(
                rs.getInt("id"),
                rs.getString("name"),
                rs.getString("description"),
                deadline,
                createdAt
        );
    }

    private Goal mapGoal(ResultSet rs) throws SQLException {
        String fin = rs.getString("finished_at");
        LocalDateTime finishedAt = (fin != null && !fin.isEmpty()) ? LocalDateTime.parse(fin) : null;
        return new Goal(
                rs.getInt("id"),
                rs.getInt("task_id"),
                rs.getString("description"),
                Ukuran.valueOf(rs.getString("ukuran")),
                Status.valueOf(rs.getString("status")),
                rs.getInt("position"),
                LocalDateTime.parse(rs.getString("updated_at")),
                finishedAt
        );
    }
}